from funcion_01 import *

# CONSIGNA: escribir pruebas usando solo assert.
# Casos sugeridos: suma positivos, suma negativos, suma cero.

def test_suma_positivos():
    assert sumar(2, 3) == 5

def test_suma_negativos():
    assert sumar(-2, -3) == -5

def test_suma_cero():
    assert sumar(0, 0) == 0
    assert sumar(5, 0) == 5
