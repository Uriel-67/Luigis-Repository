from funcion_07 import *

# CONSIGNA: escribir pruebas usando solo assert.
# Casos sugeridos: clave valida, clave corta, sin numeros, limite ocho.

def test_clave_valida():
    assert clave_valida("abcdefg1") is True

def test_clave_corta():
    assert clave_valida("abc123") is False

def test_sin_numeros():
    assert clave_valida("abcdefghij") is False

def test_limite_ocho():
    assert clave_valida("abcdefg1") is True
    assert clave_valida("abcdef1") is False
