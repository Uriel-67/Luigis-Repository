from funcion_06 import *

# CONSIGNA: escribir pruebas usando solo assert.
# Casos sugeridos: producto existente, producto inexistente, cantidad negativa.

def test_producto_existente():
    stock = {"pan": 10}
    assert actualizar_stock(stock, "pan", 5) is True
    assert stock["pan"] == 15

def test_producto_inexistente():
    stock = {"pan": 10}
    assert actualizar_stock(stock, "leche", 5) is False
    assert stock == {"pan": 10}

def test_cantidad_negativa():
    stock = {"pan": 10}
    assert actualizar_stock(stock, "pan", -3) is False
    assert stock["pan"] == 10
