from funcion_09 import *

# CONSIGNA: escribir pruebas usando solo assert.
# Casos sugeridos: dos productos, producto repetido, sin ventas, venta cero.

def test_dos_productos():
    assert resumen_ventas([("a", 2, 10), ("b", 1, 5)]) == {"a": 20, "b": 5}

def test_producto_repetido():
    assert resumen_ventas([("a", 2, 10), ("a", 3, 10)]) == {"a": 50}

def test_sin_ventas():
    assert resumen_ventas([]) == {}

def test_venta_cero():
    assert resumen_ventas([("a", 0, 10)]) == {"a": 0}
